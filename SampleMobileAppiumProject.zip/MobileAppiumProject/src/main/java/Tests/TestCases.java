package Tests;

import java.io.IOException;

import org.testng.annotations.Test;

import Base.Base;
import Pages.CartPage;
import Pages.CommonMethods;
import Pages.HomePage;
import Pages.MenuPage;
import Pages.ProductDetailsPage;
import Pages.SearchResultsPage;

public class TestCases extends Base {
	
	public static String ProductName;
	
	@Test
	public void AddProductFromSearchDetailsPage() throws InterruptedException, IOException
	{
		ProductName=CommonMethods.readDataFromPropertyFile("Product");
		System.out.println("Product Name" + ProductName);
		HomePage.SearchProduct(ProductName);
		SearchResultsPage.ValidateSearchResults();
		SearchResultsPage.ValidateVariantPopUp();
		SearchResultsPage.AddProductToCart();
		CommonMethods.NavigateToCart();
		CommonMethods.TakeSreenshot();
	}
	
	@Test
	public void NavigateToMenuPageAndValidateElements() throws IOException {
		MenuPage.ValidateMenuPageElements();
		MenuPage.ValidateContentsOfMenuPageElements();
		CommonMethods.TakeSreenshot();
	}
	
	@Test
	public void AddProductByCategoryFromProductDetailsPage() throws InterruptedException, IOException
	{
		MenuPage.SelectKitchenWareItem();
		SearchResultsPage.LoadProductDetailsPage();
		ProductDetailsPage.ValidateElementsInProductDetailsPage();
		ProductDetailsPage.AddToCartAndValidateElements();
		CommonMethods.TakeSreenshot();
	}
	
	@Test
	public void ValidateCartAndProceedToCheckOut() throws IOException
	{
		CommonMethods.NavigateToCart();
		CartPage.ValidateElementsInCartPage();
		CartPage.NavigateToCheckoutPage();
		CommonMethods.TakeSreenshot();
	}	
		
}
