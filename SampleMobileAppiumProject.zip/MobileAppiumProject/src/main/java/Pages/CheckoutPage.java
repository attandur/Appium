package Pages;

import org.openqa.selenium.By;
import org.testng.Assert;

public class CheckoutPage {
	
	//Locators
	public static By CheckOutpageTitleText = By.id("in.dmart:id/actionbarTitleText");
	public static By MobileNumberLabel     = By.id("in.dmart:id/tvMobileNumberLabel");
	public static By MobileNumberTextBox   = By.id("in.dmart:id/llLoginLayout");
	public static By ConditionPrivacy      = By.id("in.dmart:id/txtTermConditionPrivacy");
	public static By ContinueButton        = By.id("in.dmart:id/btnLoginInUser");
	
	//Methods
	public static void ValidateElementsInCheckoutPage() {
		Assert.assertEquals(CommonMethods.FindElement(CheckOutpageTitleText).isDisplayed(), "Checout page Title is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(MobileNumberLabel).isDisplayed(), "Mobile Number Label not displayed");
		Assert.assertEquals(CommonMethods.FindElement(MobileNumberTextBox).isDisplayed(), "Mobile Number Textbox is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(ConditionPrivacy).isDisplayed(), "Condition Privacy Text is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(ContinueButton).isDisplayed(), "Continue button is not displayed");
	}
}
