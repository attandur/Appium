package Pages;

import org.openqa.selenium.By;
import org.testng.Assert;

public class ProductDetailsPage {
	
	//locators
	public static By CartInDetaileSheet        = By.id("in.dmart:id/ic_cart_icon'");
	public static By SearchIconInDetailSheet   = By.id("in.dmart:id/action_search");
	public static By MoreIconInDetailSheet     = By.id("in.dmart:id/more");
	public static By NavigateBackArrow         = By.xpath("//*[@class='android.widget.ImageButton' and @content-desc='Navigate up']");
	public static By ProductTitleInDetailSheet = By.id("in.dmart:id/tvPDTitle");
	public static By ProductImageInDetailSheet = By.id("in.dmart:id/img_activity_pdp_productimage");
	public static By SavingPriceInDetailSheet  = By.id("in.dmart:id/pdSavingPriceTxt");
	public static By PricePreFixInDetailSheet  = By.id("in.dmart:id/pdDMartPricePrefixTxt");
	public static By ProductPriceInDetailSheet = By.id("in.dmart:id/pdDMartPriceTxt"); 
	public static By ProductMRPStriked         = By.id("in.dmart:id/pdMrpPriceTxt");
    public static By VariantTextInDetailSheet  = By.id("in.dmart:id/pdVariantTxt");
    public static By VariantValueText          = By.id("in.dmart:id/pdTvVariantText");
    public static By DescriptionTab            = By.xpath("//*[@class='android.widget.TextView' and @text='Description']");
    public static By CountryOfOriginTab        = By.xpath("//*[@class='android.widget.TextView' and @text='Country Of Origin']");
    public static By DisclaimerTab             = By.xpath("//*[@class='android.widget.TextView' and @text='Disclaimer']");
    public static By ManufacturerInfoTab       = By.xpath("//*[@class='android.widget.TextView' and @text='Manufacturer Info']");
    
    public static By AddToCartButton           = By.id("in.dmart:id/llAddToCartBtn");
    public static By DeleteFromCartButton      = By.id("in.dmart:id/pdButtonWidgetMinus");
    public static By QuantityText              = By.id("n.dmart:id/pdButtonWidgetQtyTxt");
    public static By PlusButton                = By.id("n.dmart:id/pdButtonWidgetPlus");
    public static By YouPayText                = By.id("in.dmart:id/pdButtonWidgetYouPayTxt");
    public static By YouSaveText               = By.id("in.dmart:id/pdButtonWidgetYouSaveTxt");
    
    //Methods
    public static void ValidateElementsInProductDetailsPage() {
		Assert.assertEquals(CommonMethods.FindElement(CartInDetaileSheet).isDisplayed(), "Cart is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(SearchIconInDetailSheet).isDisplayed(), "Search Icon is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(MoreIconInDetailSheet).isDisplayed(), "More Icon is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(ProductTitleInDetailSheet).isDisplayed(), "Product Title is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(ProductImageInDetailSheet).isDisplayed(), "Product Image is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(SavingPriceInDetailSheet).isDisplayed(), "Product Savings price is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(PricePreFixInDetailSheet).isDisplayed(), "Price Pre Fix is not displayed");
		
		Assert.assertEquals(CommonMethods.FindElement(DescriptionTab).isDisplayed(), "Description Tab is not displayed");
		CommonMethods.ClickOnElement(DescriptionTab);
		Assert.assertEquals(CommonMethods.FindElement(CountryOfOriginTab).isDisplayed(), "Country Of Origin Tab is not displayed");
		CommonMethods.ClickOnElement(CountryOfOriginTab);
		Assert.assertEquals(CommonMethods.FindElement(DisclaimerTab).isDisplayed(), "Disclaimer Tab is not displayed");
		CommonMethods.ClickOnElement(DisclaimerTab);
		Assert.assertEquals(CommonMethods.FindElement(ManufacturerInfoTab).isDisplayed(), "Manufacturer Info Tab is not displayed");
		CommonMethods.ClickOnElement(ManufacturerInfoTab);
    }
    
    public static void AddToCartAndValidateElements() {
		Assert.assertEquals(CommonMethods.FindElement(AddToCartButton).isDisplayed(), "Add To Cart button is not displayed");
		CommonMethods.ClickOnElement(AddToCartButton);
		Assert.assertEquals(CommonMethods.FindElement(QuantityText).isDisplayed(), "Quantity Text is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(DeleteFromCartButton).isDisplayed(), "Delete from Cart button is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(PlusButton).isDisplayed(), "Plus button button is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(YouPayText).isDisplayed(), "You Pay Text is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(YouSaveText).isDisplayed(), "You Save Text is not displayed");
    }
    
}
