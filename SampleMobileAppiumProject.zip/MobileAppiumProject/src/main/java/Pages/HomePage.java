package Pages;

import org.openqa.selenium.By;
import org.testng.Assert;

import Base.Base;

public class HomePage extends Base {
	  
	    // Locators
		public static By PincodePopup 	 = By.id("in.dmart:id/et_activity_pincode_pincode");
		public static By ProceedButton 	 = By.id("in.dmart:id/btn_activity_pincode_proceed");
		public static By PincodeHomepage = By.id("in.dmart:id/tvEarliestPincode");
        public static By SelectorValue 	 = By.xpath("//*[@class='android.widget.LinearLayout']");
        public static By SearchTextBox 	 = By.id("in.dmart:id/et_home_search_value");
        public static By SearchButton	 = By.id("in.dmart:id/btn_home_search_submit");
        public static By HambergerIcon   = By.xpath("//*[@class='android.widget.ImageButton']");
		
		// Methods
		public static void EnterPincode(String pincode) throws InterruptedException {
			CommonMethods.SendKeys(PincodePopup, pincode);
			CommonMethods.ClickOnElement(SelectorValue);
			CommonMethods.ClickOnElement(ProceedButton);
			Assert.assertEquals(pincode, CommonMethods.FindElement(PincodeHomepage).getText());
		}
		
		public static void SearchProduct(String productName) {
			CommonMethods.SendKeys(SearchTextBox, productName);
			CommonMethods.ClickOnElement(SearchButton);
		}
		
		public static void ClickOnHamberger() {
			CommonMethods.ClickOnElement(HambergerIcon);
		}
}
