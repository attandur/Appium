package Pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import Base.Base;

public class MenuPage extends Base {
	
	//Locators
	//public static By TitleText               = By.id("in.dmart:id/txt_fragment_navigation_name");
	public static By TitleText               = By.xpath("//*[@class='android.widget.TextView' and @text='Hi, Guest']");
	public static By LocationNavigationIcon  = By.id("in.dmart:id/img_fragment_navigation_location");
	public static By Pincode                 = By.id("in.dmart:id/txtPinCode");
	public static By City                    = By.id("in.dmart:id/txtAreaCity");
	public static By ShopByCategoryText      = By.id("in.dmart:id/txt_widget_dynamic_displaytxt");
	public static By Category_Kitchenware    = By.xpath("//*[@class='android.widget.TextView' and @text='Kitchenware']");
	public static By Category_Appliances     = By.xpath("//*[@class='android.widget.TextView' and @text='The Make-Up Store']");
	public static By Category_MakeUpStore    = By.xpath("//*[@class='android.widget.TextView' and @text='Appliances']");
	public static By Category_FrozenSnacks   = By.xpath("//*[@class='android.widget.TextView' and @text='Frozen Snacks']");
    public static By PickupUpPointList       = By.xpath("//*[@class='android.widget.TextView' and @text='Pick Up Point List']");
    public static By ContactUs               = By.xpath("//*[@class='android.widget.TextView' and @text='Contact Us']");
    public static By Refund_Terms_Policies   = By.xpath("//*[@class='android.widget.TextView' and @text='Refund, Terms and Policies']");
    public static By FAQ                     = By.xpath("//*[@class='android.widget.TextView' and @text='Frequently Asked Questions']");
    public static By AboutUs                 = By.xpath("//*[@class='android.widget.TextView' and @text='About Us']");
    public static By version                 = By.id("in.dmart:id/txt_widget_update_version");
    public static By ViewAllButton           = By.id("in.dmart:id/img_banner");    


    //Methods
    public static void ValidateMenuPageElements() {
    	
		CommonMethods.Wait();
		HomePage.ClickOnHamberger();
		Assert.assertTrue(CommonMethods.FindElement(TitleText).isDisplayed(), "Title is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(LocationNavigationIcon).isDisplayed(), "Navigation Icon is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(Pincode).isDisplayed(), "Pincode is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(City).isDisplayed(), "City is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(ShopByCategoryText).isDisplayed(), "Shop By Category Text is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(Category_Kitchenware).isDisplayed(), "Kitchenware category is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(Category_Appliances).isDisplayed(), "Appliance category is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(Category_MakeUpStore).isDisplayed(), "Makeup category is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(Category_FrozenSnacks).isDisplayed(), "Frozen Snack category is not displayed");	
		Assert.assertTrue(CommonMethods.FindElement(PickupUpPointList).isDisplayed(), "Pickup point List is not displayed");	
		Assert.assertTrue(CommonMethods.FindElement(ContactUs).isDisplayed(), "Contact Us is not displayed");	
		Assert.assertTrue(CommonMethods.FindElement(Refund_Terms_Policies).isDisplayed(), "Refund Terms and Plocicies is not displayed");	
		Assert.assertTrue(CommonMethods.FindElement(FAQ).isDisplayed(), "FAQ is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(AboutUs).isDisplayed(), "About Us is not displayed");	
		Assert.assertTrue(CommonMethods.FindElement(version).isDisplayed(), "Android Version is not displayed");	
	}

    public static void ValidateContentsOfMenuPageElements() throws IOException {
    	Assert.assertEquals(CommonMethods.FindElement(ShopByCategoryText).getText(),CommonMethods.readDataFromExcelSheet(1));
		Assert.assertEquals(CommonMethods.FindElement(Category_Kitchenware).getText(),CommonMethods.readDataFromExcelSheet(2));
		Assert.assertEquals(CommonMethods.FindElement(Category_Appliances).getText(), CommonMethods.readDataFromExcelSheet(3));
		Assert.assertEquals(CommonMethods.FindElement(Category_MakeUpStore).getText(), CommonMethods.readDataFromExcelSheet(4));
		Assert.assertEquals(CommonMethods.FindElement(Category_FrozenSnacks).getText(), CommonMethods.readDataFromExcelSheet(5));
		
		Assert.assertEquals(CommonMethods.FindElement(TitleText).getText(), CommonMethods.readDataFromPropertyFile("MenuPageTitleText"));
		Assert.assertEquals(CommonMethods.FindElement(Pincode).getText(), CommonMethods.readDataFromPropertyFile("Pincode"));
		Assert.assertEquals(CommonMethods.FindElement(City).getText(), CommonMethods.readDataFromPropertyFile("City"));
		Assert.assertEquals(CommonMethods.FindElement(PickupUpPointList).getText(), CommonMethods.readDataFromPropertyFile("PickUpList"));
		Assert.assertEquals(CommonMethods.FindElement(ContactUs).getText(), CommonMethods.readDataFromPropertyFile("Contact"));
		Assert.assertEquals(CommonMethods.FindElement(Refund_Terms_Policies).getText(), CommonMethods.readDataFromPropertyFile("Term&Policy"));
		Assert.assertEquals(CommonMethods.FindElement(FAQ).getText(), CommonMethods.readDataFromPropertyFile("FAQ"));
		Assert.assertEquals(CommonMethods.FindElement(AboutUs).getText(), CommonMethods.readDataFromPropertyFile("About"));
    	
    }
    
    public static void SelectKitchenWareItem() {
	
    	CommonMethods.ClickOnElement(Category_Kitchenware);
    	CommonMethods.ClickOnElement(ViewAllButton);
    	
    }
}
