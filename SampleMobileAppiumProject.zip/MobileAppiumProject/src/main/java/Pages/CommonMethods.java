package Pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

import Base.Base;

public class CommonMethods extends Base {
	
	//Locators
	static WebElement wl;
	public static By NavigateBackArrow = By.xpath("//*[@class='android.widget.ImageButton' and @content-desc='Navigate up']");
    public static By AddToCartButton   = By.id("in.dmart:id/ic_cart_icon");

    //Methods
	public static void SendKeys(By element, String value) {
		driver.findElement(element).sendKeys(value);
	}
	
	public static void ClickOnElement(By element) {
		driver.findElement(element).click();
	}
	
	public static WebElement FindElement(By element) {
		wl=driver.findElement(element);
		return wl;
	}

	public static void Wait() {
		   driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
	}
	
	public static void NavigateBack(){
		Wait();
		ClickOnElement(NavigateBackArrow);
	}
	
	public static void NavigateToCart() {	
		ClickOnElement(AddToCartButton);
	}
	
	public static String readDataFromPropertyFile(String key) throws IOException {
		String filepath = "/Users/anil/eclipse-workspace/MobileAppiumProject/src/test/resources/ProjectData.properties";
        File file = new File(filepath);
		FileInputStream fis = new FileInputStream(file);
		Properties prop = new Properties();
		prop.load(fis);
		
		String value=prop.getProperty(key);
		return value;
	}
	
	public static void TakeSreenshot() throws IOException {

		TakesScreenshot objTakeSS = ((TakesScreenshot) driver);
		File SrcFile = objTakeSS.getScreenshotAs(OutputType.FILE);
		File DestFile = new File("/Users/anil/eclipse-workspace/MobileAppiumProject/Screenshot/" + "Pic.png");
		FileUtils.copyFile(SrcFile, DestFile);
	}
	
	public static String readDataFromExcelSheet(int row) throws IOException {
		String pathofExcelSheet = "/Users/anil/eclipse-workspace/MobileAppiumProject/src/test/resources/DMartData.xlsx";
		File file = new File(pathofExcelSheet);
		FileInputStream fis = new FileInputStream(file);
		
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheetOfInterest = wb.getSheet("Sheet1");
		XSSFRow rowFromExcel = sheetOfInterest.getRow(row);
		String CellValue = rowFromExcel.getCell(1).getStringCellValue();
		wb.close();

		return CellValue;
	}
	
}

