package Pages;

import org.openqa.selenium.By;
import org.testng.Assert;

public class SearchResultsPage {
	
	// Locators
	public static By ProductImage 		= By.id("in.dmart:id/img_listitem_plp_productimage");
	public static By ProductTitle 		= By.id("in.dmart:id/txt_listitem_plp_title");
	public static By ProductVariant 	= By.id("in.dmart:id/txt_listitem_plp_variant");
	public static By ProductVariantInfo = By.id("in.dmart:id/txt_listitem_plp_variantinfo");
	public static By VariantDropdown    = By.id("in.dmart:id/plp_variant_downgrey");
	public static By ProductLabel 		= By.xpath("(//*[@class='android.widget.TextView' and @text='DMart'])[1]");
	public static By ProductPrice 		= By.id("in.dmart:id/txt_listitem_plp_dmartprice");
	public static By ProductSavePrice 	= By.id("in.dmart:id/linear_listitem_plp_saveprice");
	public static By ProductMRP 		= By.id("in.dmart:id/txt_listitem_plp_mrp");
	public static By AddButton			= By.id("in.dmart:id/txt_addview_plp_addtocart");
	
	public static By VariantPopUp             = By.id("in.dmart:id/design_bottom_sheet");
	public static By VariantPopUpProductTitle = By.id("in.dmart:id/txt_bottomsheet_plp_title");
	public static By VariantPopUpProductImage = By.id("in.dmart:id/img_bottomsheet_plp_productimage");
	public static By VariantPopUpCloseButton  = By.id("in.dmart:id/img_bottomsheet_plp_close");
	
	
	public static String ProductTitleInSearchResult;

	
    // Methods
	public static void ValidateSearchResults() {
		CommonMethods.Wait();
		Assert.assertTrue(CommonMethods.FindElement(ProductImage).isDisplayed(), "Product Image is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(ProductTitle).isDisplayed(), "Product Title is not displayed");
		ProductTitleInSearchResult=CommonMethods.FindElement(ProductTitle).getText();
		Assert.assertTrue(CommonMethods.FindElement(ProductVariant).isDisplayed(), "Product Variant is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(ProductVariantInfo).isDisplayed(), "Product Variant Information is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(VariantDropdown).isDisplayed(), "Variant DropDown is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(ProductPrice).isDisplayed(), "ProductLabel is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(ProductSavePrice).isDisplayed(), "Product Save price is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(ProductMRP).isDisplayed(), "Product MRP is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(AddButton).isDisplayed(), "Add to cart button is not displayed");	
	}
	
	public static void ValidateVariantPopUp(){
		CommonMethods.ClickOnElement(VariantDropdown);
		Assert.assertTrue(CommonMethods.FindElement(VariantPopUp).isDisplayed(), "Variant Pop-up is not displayed");
		Assert.assertTrue(CommonMethods.FindElement(VariantPopUpProductTitle).isDisplayed(), "Product Title in Variant Pop-up is not displayed");
		Assert.assertEquals(ProductTitleInSearchResult, CommonMethods.FindElement(VariantPopUpProductTitle).getText());
		Assert.assertTrue(CommonMethods.FindElement(VariantPopUpProductImage).isDisplayed(), "Product Image in Variant Pop-up is not displayed");
		CommonMethods.ClickOnElement(VariantPopUpCloseButton);

	}
	
	public static void AddProductToCart() {
		CommonMethods.ClickOnElement(AddButton);
	}

	public static void LoadProductDetailsPage() {
		CommonMethods.ClickOnElement(ProductImage);
	}
	
}
