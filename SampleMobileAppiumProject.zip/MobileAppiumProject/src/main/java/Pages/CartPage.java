package Pages;

import org.openqa.selenium.By;
import org.testng.Assert;

public class CartPage {
	
	//Locators
	public static By CartTitleText 	      = By.id("in.dmart:id/actionbarTitleText");
	public static By NavigateBackArrow    = By.xpath("//*[@class='android.widget.ImageButton' and @content-desc='Navigate up']");
	public static By CartPriceSavings     = By.id("in.dmart:id/cartPriceSummarySavings");
	public static By CartPriceTotal       = By.id("in.dmart:id/cartPriceSummaryTotal");
	public static By MyCartHeader         = By.id("in.dmart:id/txtCartWidgetHeader");
	public static By ProductNameInCart    = By.id("in.dmart:id/txtCartWidgetProductName");
	public static By ProductImageInCart   = By.id("in.dmart:id/imgCartWidgetProduct");
	public static By ProductVariantInCart = By.id("in.dmart:id/txtCartWidgetProductVariant");
	public static By YouPayTextInCart     = By.id("in.dmart:id/txtCartWidgetYouPayValue");
	public static By YouSaveTextInCart    = By.id("in.dmart:id/txtCartWidgetYouSaveValue");
	public static By RemoveProductButton  = By.id("in.dmart:id/imgCartWidgetProductRemove");
	public static By ProductQuantityMinus = By.id("in.dmart:id/rlCartWidgetMinus");
	public static By ProductQuantityPlus  = By.id("in.dmart:id/rlCartWidgetPlus\n");
	public static By RemoveAllButton      = By.xpath("//*[@class='android.widget.TextView' and @text='Remove all']");
	public static By ProceedToCheckout    = By.id("in.dmart:id/btnProceedToCheckout");

	//Methods
	public static void ValidateElementsInCartPage() {
		
		Assert.assertEquals(CommonMethods.FindElement(CartTitleText).isDisplayed(), "Cart Title is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(NavigateBackArrow).isDisplayed(), "Navigate back button is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(CartPriceSavings).isDisplayed(), "Cart Price Savings Text is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(CartPriceTotal).isDisplayed(), "Cart Total Price is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(MyCartHeader).isDisplayed(), "Cart Header Text is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(ProductNameInCart).isDisplayed(), "Product Name is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(ProductImageInCart).isDisplayed(), "Product Image is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(YouPayTextInCart).isDisplayed(), "You Pay Text is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(YouSaveTextInCart).isDisplayed(), "You Save Text is not displayed");	
		Assert.assertEquals(CommonMethods.FindElement(RemoveProductButton).isDisplayed(), "Remove Product Button is not displayed");	
		Assert.assertEquals(CommonMethods.FindElement(ProductQuantityMinus).isDisplayed(), "Decrease Quantity Button is not displayed");	
		Assert.assertEquals(CommonMethods.FindElement(ProductQuantityPlus).isDisplayed(), "Increase Quantity Button is not displayed");	
		Assert.assertEquals(CommonMethods.FindElement(RemoveAllButton).isDisplayed(), "Remove All products Button is not displayed");
		Assert.assertEquals(CommonMethods.FindElement(ProceedToCheckout).isDisplayed(), "Proceed to checkout Button is not displayed");	
	}
	
	public static void NavigateToCheckoutPage() {
    	CommonMethods.ClickOnElement(ProceedToCheckout);
	}

}
