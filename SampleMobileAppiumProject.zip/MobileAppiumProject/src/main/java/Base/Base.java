package Base;

import java.io.File;

import java.io.IOException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import Pages.CommonMethods;
import Pages.HomePage;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Base {
	
	public static AndroidDriver driver;
	public static String DeviceName;
	public static String PlatformName;
	public static String PincodeValue;

	@BeforeTest
	public void Start() throws InterruptedException, IOException {
		
		//File appDir = new File("/Users/anil/Documents/AndroidAPK/DMart.apk");
		File appDir = new File(CommonMethods.readDataFromPropertyFile("ApkFilePath"));
		DesiredCapabilities cap = new DesiredCapabilities();
		
		DeviceName=CommonMethods.readDataFromPropertyFile("Device");
		System.out.println("Deice Name" + DeviceName);
		PlatformName=CommonMethods.readDataFromPropertyFile("Platform");
		System.out.println("Deice Name" + PlatformName);

		PincodeValue=CommonMethods.readDataFromPropertyFile("Pincode");
		
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, DeviceName);
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME,PlatformName);
		cap.setCapability("app", appDir.getAbsolutePath());
		
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),cap);
		CommonMethods.Wait();
		HomePage.EnterPincode(PincodeValue);
	}
	
	@AfterTest
	public void End() {
		driver.quit();
	}

}


